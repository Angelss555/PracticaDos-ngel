-- 1. Insertamos Categorías primero (porque los productos las necesitan)
-- ID 1: Electrónica (Activa)
INSERT INTO categorias (descripcion, activo) VALUES ('Electrónica', true);
-- ID 2: Línea Blanca (Activa)
INSERT INTO categorias (descripcion, activo) VALUES ('Hogar', true);
-- ID 3: Juguetes (Inactiva - para probar el filtro de "categoría activa")
INSERT INTO categorias (descripcion, activo) VALUES ('Hobbies', false);

-- 2. Insertamos Productos
-- Productos de Electrónica (Categoría 1)
INSERT INTO productos (nombre, precio, existencias, activo, categoria_id) VALUES ('Laptop Dell XPS', 1200.50, 15, true, 1);
INSERT INTO productos (nombre, precio, existencias, activo, categoria_id) VALUES ('Mouse Logitech', 45.00, 50, true, 1);
INSERT INTO productos (nombre, precio, existencias, activo, categoria_id) VALUES ('Monitor Samsung 27 pulgadas', 250.00, 8, true, 1);
INSERT INTO productos (nombre, precio, existencias, activo, categoria_id) VALUES ('Teclado Dañado', 10.00, 0, false, 1); -- Inactivo

-- Productos de Línea Blanca (Categoría 2)
INSERT INTO productos (nombre, precio, existencias, activo, categoria_id) VALUES ('Refrigeradora LG', 800.00, 5, true, 2);
INSERT INTO productos (nombre, precio, existencias, activo, categoria_id) VALUES ('Microondas Panasonic', 150.00, 20, true, 2);

-- Productos de Juguetes (Categoría 3 - Esta categoría está inactiva)
INSERT INTO productos (nombre, precio, existencias, activo, categoria_id) VALUES ('Funko Pop', 35.00, 100, true, 3);
INSERT INTO productos (nombre, precio, existencias, activo, categoria_id) VALUES ('Skateboard Toy Machine Complete', 180.00, 5, true, 3);