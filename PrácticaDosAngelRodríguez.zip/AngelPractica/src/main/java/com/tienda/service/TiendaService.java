package com.tienda.service;

import com.tienda.model.Producto;
import com.tienda.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */

@Service
public class TiendaService {
    
    private final ProductoRepository productoRepo;

    //Inicaializar dependecias
    public TiendaService(ProductoRepository productoRepo) {
        this.productoRepo = productoRepo;
    }

    //Cargar métodos para filtrar precios y existencias
    public List<Producto> buscarProductos(double min, double max, int exist, String desc, String tipo) {
        if ("jpql".equals(tipo)) {
            return productoRepo.buscarPorFiltrosJpql(min, max, exist, desc);
        } else if ("nativa".equals(tipo)) {
            return productoRepo.buscarPorFiltrosNativo(min, max, exist, desc);
        }
        return productoRepo.findByActivoTrueAndPrecioBetweenAndExistenciasGreaterThanAndCategoriaActivoTrueAndCategoriaDescripcionContainingOrderByPrecioAsc(min, max, exist, desc);
    }
}