package com.tienda.repository;

import com.tienda.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */
public interface ProductoRepository extends JpaRepository<Producto, Long> {
    
    //Creamos el método derivado
    List<Producto> findByActivoTrueAndPrecioBetweenAndExistenciasGreaterThanAndCategoriaActivoTrueAndCategoriaDescripcionContainingOrderByPrecioAsc(
            double precioMin, double precioMax, int existenciasMin, String descripcionCategoria);

    //Creamos el método JPQL
    @Query("SELECT p FROM Producto p JOIN p.categoria c WHERE p.activo = true AND p.precio BETWEEN :precioMin AND :precioMax AND p.existencias > :existenciasMin AND c.activo = true AND c.descripcion LIKE %:descCategoria% ORDER BY p.precio ASC")
    List<Producto> buscarPorFiltrosJpql(@Param("precioMin") double pMin, @Param("precioMax") double pMax, @Param("existenciasMin") int eMin, @Param("descCategoria") String desc);

    //Creamos SQL Nativa
    @Query(value = "SELECT p.* FROM productos p INNER JOIN categorias c ON p.categoria_id = c.id WHERE p.activo = true AND p.precio BETWEEN :precioMin AND :precioMax AND p.existencias > :existenciasMin AND c.activo = true AND c.descripcion LIKE %:descCategoria% ORDER BY p.precio ASC", nativeQuery = true)
    List<Producto> buscarPorFiltrosNativo(@Param("precioMin") double pMin, @Param("precioMax") double pMax, @Param("existenciasMin") int eMin, @Param("descCategoria") String desc);
}