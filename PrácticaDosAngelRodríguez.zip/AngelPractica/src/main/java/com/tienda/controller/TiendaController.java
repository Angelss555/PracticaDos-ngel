package com.tienda.controller;

import com.tienda.service.TiendaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */

@Controller
public class TiendaController {
    private final TiendaService tiendaService;

    //Inicializar el constructor
    public TiendaController(TiendaService tiendaService) {
        this.tiendaService = tiendaService;
    }

    //Cargar el index de templates
    @GetMapping("/")
    public String index() {
        return "index";
    }

    //Método para buscar productos
    @GetMapping("/buscar/productos")
    public String buscarProductos(
            @RequestParam double precioMin, @RequestParam double precioMax,
            @RequestParam int existenciasMin, @RequestParam String descCategoria,
            @RequestParam String tipoConsulta, Model model) {
        
        model.addAttribute("productos", tiendaService.buscarProductos(precioMin, precioMax, existenciasMin, descCategoria, tipoConsulta));
        return "index"; //Esto regresa a la misma vista pero ahora con datos
    }
}