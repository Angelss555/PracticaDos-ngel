package com.tienda.model;

import jakarta.persistence.*;
import java.util.List;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */

@Entity
@Table(name = "categorias")
public class Categoria {
    
    //Creamos los atributos de la tabla
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String descripcion;
    private boolean activo;
    
    //Definimos la relación
    @OneToMany(mappedBy = "categoria")
    private List<Producto> productos;
    
    //Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public List<Producto> getProductos() { return productos; }
    public void setProductos(List<Producto> productos) { this.productos = productos; }
    
}