package com.tienda.model;

import jakarta.persistence.*;

/**
 *
 * @author Ángel Felipe Rodríguez Vargas
 */

@Entity
@Table(name = "productos")
public class Producto {
    
    //Creamos los atributos de las tablas
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private double precio;
    private int existencias;
    private boolean activo;
    
    //Definimos la relación
    @ManyToOne
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;
    
    //Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getExistencias() { return existencias; }
    public void setExistencias(int existencias) { this.existencias = existencias; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
    
}